"""ScamShield backend (Ahmed). Run: python -m flask --app app run"""
import os
import re
import sqlite3

from flask import Flask, jsonify, render_template, request, session

import auth
from scamshield_detection.flask_adapter import init_app as init_detection
from scamshield_storage import get_db, init_app

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def create_app(config=None):
    app = Flask(__name__, instance_relative_config=True)
    app.config.update(
        SECRET_KEY=os.environ.get("SCAMSHIELD_SECRET_KEY", "dev-only-change-me"),
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        MAX_CONTENT_LENGTH=64 * 1024,
    )
    if config:
        app.config.update(config)

    # Callbacks must be set BEFORE init_app (see Lavinia's README).
    app.config["SCAMSHIELD_ACTOR_PROVIDER"] = auth.current_storage_account
    app.config["SCAMSHIELD_CSRF_VALIDATOR"] = auth.validate_write_request
    init_detection(app)  # Daneil's rule engine registers SCAMSHIELD_DETECTOR
    init_app(app)

    def error(code, message, status):
        return jsonify(error={"code": code, "message": message}), status

    def json_body(*fields):
        data = request.get_json(silent=True)
        if not isinstance(data, dict) or any(not isinstance(data.get(f), str) for f in fields):
            return None
        return data

    @app.get("/")
    def index():
        return render_template("index.html")

    @app.get("/family")
    def family_dashboard():
        return render_template("family.html")

    # ---- auth API ----------------------------------------------------------
    @app.post("/api/auth/register")
    def register():
        data = json_body("name", "email", "password", "role")
        if data is None:
            return error("invalid_fields", "Send name, email, password and role.", 400)
        email = data["email"].strip().lower()
        if not EMAIL_RE.match(email) or not data["name"].strip():
            return error("invalid_input", "Enter a name and a valid email address.", 400)
        if len(data["password"]) < 8:
            return error("weak_password", "Password must be at least 8 characters.", 400)
        if data["role"] not in ("older", "family"):
            return error("invalid_role", "Role must be older or family.", 400)
        if auth.find_by_email(email):
            return error("email_taken", "An account with this email already exists.", 409)
        try:
            user = get_db().create_user(data["name"], email, data["role"])
            auth.create_account(email, data["password"], user["user_id"], data["role"])
        except sqlite3.IntegrityError:
            return error("email_taken", "An account with this email already exists.", 409)
        except ValueError as exc:
            return error("invalid_input", str(exc), 400)
        auth.login_session({"storage_user_id": user["user_id"], "role": data["role"]})
        return jsonify(user_id=user["user_id"], role=data["role"], csrf_token=session["csrf"]), 201

    @app.post("/api/auth/login")
    def login():
        data = json_body("email", "password")
        if data is None:
            return error("invalid_fields", "Send email and password.", 400)
        account = auth.verify_login(data["email"].strip().lower(), data["password"])
        if account is None:
            return error("bad_credentials", "Email or password is incorrect.", 401)
        auth.login_session(account)
        return jsonify(user_id=account["storage_user_id"], role=account["role"], csrf_token=session["csrf"])

    @app.get("/api/auth/me")
    def me():
        uid = auth.current_storage_account()
        if uid is None:
            return error("login_required", "Sign in to use this feature.", 401)
        return jsonify(user_id=uid, role=session["role"], csrf_token=session["csrf"])

    @app.post("/api/auth/logout")
    def logout():
        if not auth.validate_write_request():
            return error("request_rejected", "The write-request check failed.", 403)
        session.clear()
        return jsonify(ok=True)

    # ---- family linking by email (older user invites a family account) ----
    @app.post("/api/family/link")
    def link_family():
        uid = auth.current_storage_account()
        if uid is None:
            return error("login_required", "Sign in to use this feature.", 401)
        if not auth.validate_write_request():
            return error("request_rejected", "The write-request check failed.", 403)
        if session.get("role") != "older":
            return error("access_denied", "Only older accounts can add family members.", 403)
        data = json_body("family_email")
        if data is None:
            return error("invalid_fields", "Send family_email.", 400)
        target = auth.find_by_email(data["family_email"].strip().lower())
        if target is None or target["role"] != "family":
            return error("not_found", "No family account with that email.", 404)
        link = get_db().link_family(uid, target["storage_user_id"], actor_user_id=uid)
        return jsonify(link), 201

    return app


app = create_app()
