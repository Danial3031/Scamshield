import os, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from app import create_app
from scamshield_storage.contracts import validate_result

SCAM = "URGENT: your bank account will be suspended. Verify your password at http://bit.ly/x or send gift cards"
SAFE = "Hi, are we still having lunch on Sunday?"


class Backend(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.app = create_app({"TESTING": True})
        self.app.instance_path = self.tmp.name
        self.c = self.app.test_client()

    def tearDown(self):
        self.tmp.cleanup()

    def reg(self, client, email, role, name="User"):
        r = client.post("/api/auth/register", json={"name": name, "email": email, "password": "password123", "role": role})
        self.assertEqual(r.status_code, 201, r.get_json())
        return r.get_json()

    def post(self, client, path, token, body):
        return client.post(path, json=body, headers={"X-CSRF-Token": token})

    def test_detector_contract(self):
        with self.app.app_context():
            from scamshield_detection.flask_adapter import evaluate_message
            for text in (SCAM, SAFE):
                validate_result(evaluate_message(text))
            self.assertEqual(evaluate_message(SCAM)["risk_level"], "High")
            self.assertEqual(evaluate_message(SAFE)["risk_level"], "Low")

    def test_signed_out_rejected(self):
        self.assertEqual(self.c.get("/api/scamshield/history").status_code, 401)
        self.assertEqual(self.c.post("/api/scamshield/scan", json={"message_text": "x"}).status_code, 401)

    def test_register_validation_and_duplicate(self):
        bad = self.c.post("/api/auth/register", json={"name": "A", "email": "a@b.co", "password": "short", "role": "older"})
        self.assertEqual(bad.status_code, 400)
        self.reg(self.c, "a@b.co", "older")
        other = self.app.test_client()
        dup = other.post("/api/auth/register", json={"name": "A", "email": "A@B.co", "password": "password123", "role": "older"})
        self.assertEqual(dup.status_code, 409)

    def test_login(self):
        self.reg(self.c, "a@b.co", "older")
        c2 = self.app.test_client()
        self.assertEqual(c2.post("/api/auth/login", json={"email": "a@b.co", "password": "wrongwrong"}).status_code, 401)
        self.assertEqual(c2.post("/api/auth/login", json={"email": "nobody@b.co", "password": "password123"}).status_code, 401)
        self.assertEqual(c2.post("/api/auth/login", json={"email": "a@b.co", "password": "password123"}).status_code, 200)

    def test_csrf_required_for_scan(self):
        tok = self.reg(self.c, "a@b.co", "older")["csrf_token"]
        self.assertEqual(self.c.post("/api/scamshield/scan", json={"message_text": SCAM}).status_code, 403)
        self.assertEqual(self.post(self.c, "/api/scamshield/scan", "wrong", {"message_text": SCAM}).status_code, 403)
        self.assertEqual(self.post(self.c, "/api/scamshield/scan", tok, {"message_text": SCAM}).status_code, 201)

    def test_browser_score_rejected(self):
        tok = self.reg(self.c, "a@b.co", "older")["csrf_token"]
        r = self.post(self.c, "/api/scamshield/scan", tok, {"message_text": SAFE, "score": 99})
        self.assertEqual(r.status_code, 400)

    def test_family_alert_flow(self):
        older = self.reg(self.c, "mum@x.co", "older")
        fam_client = self.app.test_client()
        fam = self.reg(fam_client, "son@x.co", "family")
        stranger_client = self.app.test_client()
        stranger = self.reg(stranger_client, "other@x.co", "family")

        # family cannot scan; older can link; unknown email 404
        self.assertEqual(self.post(fam_client, "/api/scamshield/scan", fam["csrf_token"], {"message_text": SCAM}).status_code, 403)
        self.assertEqual(self.post(self.c, "/api/family/link", older["csrf_token"], {"family_email": "no@x.co"}).status_code, 404)
        self.assertEqual(self.post(fam_client, "/api/family/link", fam["csrf_token"], {"family_email": "son@x.co"}).status_code, 403)
        self.assertEqual(self.post(self.c, "/api/family/link", older["csrf_token"], {"family_email": "son@x.co"}).status_code, 201)

        scan = self.post(self.c, "/api/scamshield/scan", older["csrf_token"], {"message_text": SCAM})
        self.assertEqual(scan.status_code, 201)
        self.assertEqual(scan.get_json()["alerts_created"], 1)
        low = self.post(self.c, "/api/scamshield/scan", older["csrf_token"], {"message_text": SAFE})
        self.assertEqual(low.get_json()["alerts_created"], 0)

        alerts = fam_client.get("/api/scamshield/family/alerts").get_json()["alerts"]
        self.assertEqual(len(alerts), 1)
        self.assertEqual(stranger_client.get("/api/scamshield/family/alerts").get_json()["alerts"], [])
        self.assertEqual(len(self.c.get("/api/scamshield/history").get_json()["items"]), 2)
        self.assertEqual(fam_client.get("/api/scamshield/history").status_code, 403)

        alert_id = alerts[0]["alert_id"]
        self.assertEqual(self.post(stranger_client, f"/api/scamshield/family/alerts/{alert_id}/review", stranger["csrf_token"], {}).status_code, 403)
        self.assertEqual(self.post(fam_client, f"/api/scamshield/family/alerts/{alert_id}/review", fam["csrf_token"], {}).status_code, 200)

    def test_logout(self):
        tok = self.reg(self.c, "a@b.co", "older")["csrf_token"]
        self.assertEqual(self.post(self.c, "/api/auth/logout", tok, {}).status_code, 200)
        self.assertEqual(self.c.get("/api/auth/me").status_code, 401)

    def test_family_dashboard_pages(self):
        self.assertEqual(self.c.get("/family").status_code, 200)
        self.assertEqual(self.c.get("/static/family.js").status_code, 200)
        self.assertEqual(self.c.get("/static/family.css").status_code, 200)

    def test_homepage(self):
        self.assertEqual(self.c.get("/").status_code, 200)


if __name__ == "__main__":
    unittest.main()
