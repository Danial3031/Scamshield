"""Create demo accounts and alerts so the family dashboard can be shown.
Run once:  python seed_demo.py     (then start the app and open /family)
Accounts (password for all: password123):
    margaret@example.com (older)   daniel@example.com (family, linked to Margaret)
"""
import auth
from app import create_app
from scamshield_detection.flask_adapter import evaluate_message
from scamshield_storage import get_db

MESSAGES = [
    "URGENT: Your bank account will be suspended. Verify your password at http://bit.ly/secure-login within 2 hours.",
    "Congratulations! You have won a prize. Claim your free gift now: www.prize-claim.example",
    "HMRC final notice: unpaid tax, legal action will follow. Pay today with gift cards.",
    "Hi, are we still having lunch on Sunday?",
    "Hi mum, I lost my phone, this is my new number. Please send money by bank transfer today.",
]

app = create_app()
with app.app_context():
    if auth.find_by_email("margaret@example.com"):
        raise SystemExit("Demo data already exists. Delete the instance folder to start again.")
    db = get_db()
    older = db.create_user("Margaret", "margaret@example.com", "older")
    family = db.create_user("Daniel", "daniel@example.com", "family")
    auth.create_account("margaret@example.com", "password123", older["user_id"], "older")
    auth.create_account("daniel@example.com", "password123", family["user_id"], "family")
    uid = older["user_id"]
    db.link_family(uid, family["user_id"], actor_user_id=uid)
    for text in MESSAGES:
        saved = db.record_scan(uid, text, evaluate_message(text), actor_user_id=uid)
        print(f'{saved["result"]["risk_level"]:6} {saved["result"]["score"]:3}  alerts={saved["alerts_created"]}  {text[:50]}')
