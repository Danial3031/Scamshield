"""ScamShield database and rule-engine modules for the student prototype."""

__version__ = "1.0.0"
