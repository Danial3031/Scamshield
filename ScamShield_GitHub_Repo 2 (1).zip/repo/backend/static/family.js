"use strict";
// Family dashboard (Adnan). Reads /api/scamshield/family/alerts and marks alerts reviewed.
// Message text comes from untrusted senders, so everything is rendered with textContent.
const PAGE = 20, POLL_MS = 30000;
let csrf = "", filter = "new", alerts = [], offset = 0, hasMore = false, known = new Set(), timer = null;
const $ = id => document.getElementById(id);

function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text !== undefined) e.textContent = text;
  return e;
}

async function api(path, method = "GET", body) {
  const r = await fetch(path, {
    method, credentials: "same-origin",
    headers: { "Content-Type": "application/json", "X-CSRF-Token": csrf },
    body: body === undefined ? undefined : JSON.stringify(body)
  });
  let j = {};
  try { j = await r.json(); } catch (_) {}
  if (!r.ok) { const e = new Error(j.error?.message || "Something went wrong. Please try again."); e.status = r.status; throw e; }
  return j;
}

function show(signedIn) { $("login").hidden = signedIn; $("dash").hidden = !signedIn; }

function formatTime(iso) {
  const d = new Date(iso);
  return isNaN(d) ? "" : d.toLocaleString([], { dateStyle: "medium", timeStyle: "short" });
}

function render() {
  const box = $("alerts");
  box.replaceChildren();
  const unreviewed = alerts.filter(a => !a.reviewed_at).length;
  $("statNew").textContent = unreviewed;
  $("statDone").textContent = alerts.length - unreviewed;
  const shown = filter === "new" ? alerts.filter(a => !a.reviewed_at) : alerts;
  if (!shown.length) {
    box.append(el("p", "empty", filter === "new" ? "No alerts need your attention. All clear." : "No alerts yet."));
  }
  for (const a of shown) box.append(card(a));
  $("moreBtn").hidden = !hasMore;
}

function card(a) {
  const r = a.result || {};
  const c = el("article", "alert" + (a.reviewed_at ? "" : " unreviewed") + (a._fresh ? " fresh" : ""));
  const head = el("div", "alert-head");
  head.append(el("span", "who", a.older_name || "Your relative"), el("span", "when", formatTime(a.created_at)));
  c.append(head);
  c.append(el("span", "badge", `${r.risk_level || "High"} risk - score ${r.score ?? "?"}/100`));
  const meter = el("div", "meter"), fill = el("i");
  fill.style.width = Math.max(0, Math.min(100, Number(r.score) || 0)) + "%";
  meter.append(fill); c.append(meter);
  c.append(el("div", "msg", a.message_text));
  const ul = el("ul");
  for (const reason of r.reasons || []) ul.append(el("li", "", reason));
  c.append(ul);
  const d = el("details");
  d.append(el("summary", "", "Technical details"));
  d.append(el("div", "", `Rules: ${(r.matched_rules || []).join(", ")} | Engine: ${r.engine_version || ""}`));
  c.append(d);
  if (a.reviewed_at) {
    c.append(el("p", "done", "Reviewed " + formatTime(a.reviewed_at)));
  } else {
    c.append(el("p", "advice", "Suggested step: call them on a number you already know, and tell them not to click links or share codes."));
    const b = el("button", "primary", "Mark as reviewed");
    b.addEventListener("click", () => review(a, b));
    c.append(b);
  }
  return c;
}

async function review(a, btn) {
  btn.disabled = true; btn.textContent = "Saving...";
  try {
    await api(`/api/scamshield/family/alerts/${encodeURIComponent(a.alert_id)}/review`, "POST", {});
    a.reviewed_at = new Date().toISOString();
    notice("");
  } catch (e) {
    btn.disabled = false; btn.textContent = "Mark as reviewed";
    notice(e.message);
  }
  render();
}

function notice(msg) { $("notice").textContent = msg; $("notice").hidden = !msg; }

async function load(reset) {
  if (reset) { offset = 0; alerts = []; }
  try {
    const j = await api(`/api/scamshield/family/alerts?limit=${PAGE}&offset=${offset}`);
    const batch = j.alerts || [];
    for (const a of batch) { if (known.size && !known.has(a.alert_id)) a._fresh = true; known.add(a.alert_id); }
    alerts = reset ? batch : alerts.concat(batch);
    offset += batch.length; hasMore = batch.length === PAGE;
    $("status").textContent = "Updated " + new Date().toLocaleTimeString([], { timeStyle: "short" });
    notice("");
    render();
  } catch (e) {
    if (e.status === 401) return signOutUI();
    notice(e.status === 403 ? "This dashboard is for family accounts only." : e.message);
  }
}

// Poll only the first page; new alerts are merged to the top without losing reviewed state.
async function poll() {
  try {
    const j = await api(`/api/scamshield/family/alerts?limit=${PAGE}&offset=0`);
    const fresh = (j.alerts || []).filter(a => !known.has(a.alert_id));
    for (const a of fresh) { a._fresh = true; known.add(a.alert_id); }
    if (fresh.length) { alerts = fresh.concat(alerts); offset += fresh.length; notice(`${fresh.length} new alert${fresh.length > 1 ? "s" : ""}`); render(); }
    $("status").textContent = "Updated " + new Date().toLocaleTimeString([], { timeStyle: "short" });
  } catch (e) { if (e.status === 401) signOutUI(); }
}

function enter(j) {
  if (j.role !== "family") { show(false); $("loginError").textContent = "This page is for family accounts. Older users should use the main page."; return; }
  csrf = j.csrf_token; known = new Set(); show(true); load(true);
  clearInterval(timer); timer = setInterval(poll, POLL_MS);
}
function signOutUI() { clearInterval(timer); csrf = ""; show(false); }

$("loginBtn").addEventListener("click", async () => {
  $("loginError").textContent = "";
  try { enter(await api("/api/auth/login", "POST", { email: $("email").value, password: $("password").value })); }
  catch (e) { $("loginError").textContent = e.message; }
});
$("password").addEventListener("keydown", e => { if (e.key === "Enter") $("loginBtn").click(); });
$("logoutBtn").addEventListener("click", async () => { try { await api("/api/auth/logout", "POST", {}); } catch (_) {} signOutUI(); });
$("moreBtn").addEventListener("click", () => load(false));
document.querySelectorAll(".tab").forEach(t => t.addEventListener("click", () => {
  document.querySelectorAll(".tab").forEach(x => x.classList.toggle("active", x === t));
  filter = t.dataset.filter; render();
}));

api("/api/auth/me").then(enter).catch(() => show(false));
