"""ScamShield SQL storage and its Flask connection."""

from .contracts import ContractError, validate_result
from .database import AccessDenied, Database, NotFound
from .flask_extension import get_db, init_app

__version__ = "1.0.0"
__all__ = ["AccessDenied", "ContractError", "Database", "NotFound", "get_db", "init_app", "validate_result"]
