-- Parameterised query examples for the trusted backend.
-- :user_id, :limit and :offset are bound values, not string substitutions.

-- Older account history. Check the authenticated actor before this query.
SELECT m.message_id, m.message_text, m.received_at,
       s.scan_id, s.score, s.risk_level, s.reasons_json,
       s.matched_rules_json, s.engine_version
FROM Messages AS m
LEFT JOIN ScanResults AS s ON s.message_id = m.message_id
WHERE m.user_id = :user_id
ORDER BY m.message_id DESC
LIMIT :limit OFFSET :offset;

-- Alerts visible to an active family relationship.
SELECT a.alert_id, a.scan_id, a.relationship_id, a.reviewed_at,
       m.message_text, m.user_id AS older_user_id, s.risk_level, s.score
FROM Alerts AS a
JOIN FamilyRelationships AS f ON f.relationship_id = a.relationship_id
JOIN ScanResults AS s ON s.scan_id = a.scan_id
JOIN Messages AS m ON m.message_id = s.message_id
WHERE f.family_user_id = :user_id AND f.active = 1 AND s.risk_level = 'High'
ORDER BY a.alert_id DESC
LIMIT :limit OFFSET :offset;

-- Expected empty result when the schema is consistent.
PRAGMA foreign_key_check;
