"""Per-application storage, optional JSON routes and a local database check."""

import json
from pathlib import Path
import sqlite3
import threading

import click
from flask import current_app

from .database import Database

EXTENSION_KEY = "scamshield_storage"


def _objects(connection):
    return {
        (kind, name): " ".join(sql.split())
        for kind, name, sql in connection.execute(
            "SELECT type, name, sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' AND sql IS NOT NULL"
        )
    }


def _check_existing_schema(path):
    """Inspect existing files read-only; never migrate an unrelated database."""
    if not path.exists():
        return
    expected = sqlite3.connect(":memory:")
    try:
        expected.executescript(Path(__file__).with_name("schema.sql").read_text(encoding="utf-8"))
        wanted = _objects(expected)
    finally:
        expected.close()
    existing = sqlite3.connect(path.as_uri() + "?mode=ro", uri=True)
    try:
        actual = _objects(existing)
        if actual and actual != wanted:
            raise RuntimeError(
                "SCAMSHIELD_DATABASE has a different schema. Choose a separate file or plan a migration."
            )
        if actual and existing.execute("PRAGMA foreign_key_check").fetchone() is not None:
            raise RuntimeError("The existing database has broken foreign key relationships.")
    finally:
        existing.close()


def get_db():
    """Return the current application's repository, creating its tables on first use."""
    state = current_app.extensions.get(EXTENSION_KEY)
    if state is None:
        raise RuntimeError("Call scamshield_storage.init_app(app) during application setup.")
    with state["lock"]:
        configured = current_app.config.get("SCAMSHIELD_DATABASE")
        if configured is None:
            path = Path(current_app.instance_path) / "scamshield.sqlite3"
        else:
            if str(configured) == ":memory:":
                raise ValueError("SCAMSHIELD_DATABASE must be a file path.")
            path = Path(configured)
            if not path.is_absolute():
                path = Path(current_app.instance_path) / path
        path = path.resolve()
        if state["database"] is not None:
            if path != state["path"]:
                raise RuntimeError("Set SCAMSHIELD_DATABASE before the first database operation.")
            return state["database"]
        _check_existing_schema(path)
        database = Database(path)
        database.initialize()
        state.update(database=database, path=path)
        return database


def init_app(app):
    """Attach storage without changing templates, login code or detector rules."""
    if EXTENSION_KEY in app.extensions:
        return app.extensions[EXTENSION_KEY]
    if app.config.get("SCAMSHIELD_REGISTER_API", True):
        from .api import create_blueprint

        prefix = app.config.get("SCAMSHIELD_API_PREFIX", "/api/scamshield")
        if not isinstance(prefix, str) or not prefix.startswith("/") or prefix in ("/", ""):
            raise ValueError("SCAMSHIELD_API_PREFIX must be a non-root URL path.")
        prefix = prefix.rstrip("/")
        occupied = {rule.rule for rule in app.url_map.iter_rules()}
        if any(route == prefix or route.startswith(prefix + "/") for route in occupied):
            raise RuntimeError("The ScamShield API prefix is already used. Choose another prefix.")
        if "scamshield_storage_api" in app.blueprints:
            raise RuntimeError("The scamshield_storage_api blueprint name is already registered.")
        app.register_blueprint(create_blueprint(), url_prefix=prefix)
    state = {"database": None, "path": None, "lock": threading.RLock()}
    app.extensions[EXTENSION_KEY] = state

    @app.cli.command("scamshield-db-check")
    def database_check():
        """Create/check this component's tables and report local row counts."""
        database = get_db()
        with database.connection() as connection:
            counts = {
                name: connection.execute(f'SELECT COUNT(*) FROM "{name}"').fetchone()[0]
                for name in ("Users", "Messages", "ScanResults", "FamilyRelationships", "Alerts")
            }
            result = {
                "tables": counts,
                "foreign_keys": connection.execute("PRAGMA foreign_keys").fetchone()[0],
                "recursive_triggers": connection.execute("PRAGMA recursive_triggers").fetchone()[0],
                "foreign_key_violations": [list(row) for row in connection.execute("PRAGMA foreign_key_check")],
            }
        click.echo(json.dumps(result, indent=2))

    return state
