"""Validation of a detector result supplied to persistence."""

RESULT_KEYS = frozenset({"score", "risk_level", "reasons", "matched_rules", "engine_version"})


class ContractError(ValueError):
    """The supplied result does not meet the storage contract."""


def validate_result(result):
    """Return a detached JSON-compatible result; do not calculate risk or scores."""
    if not isinstance(result, dict) or set(result) != RESULT_KEYS:
        raise ContractError("result must have exactly score, risk_level, reasons, matched_rules and engine_version")
    score = result["score"]
    if type(score) is not int or not 0 <= score <= 100:
        raise ContractError("score must be an integer from 0 to 100")
    if result["risk_level"] not in ("Low", "Medium", "High"):
        raise ContractError("risk_level must be Low, Medium or High")
    for name in ("reasons", "matched_rules"):
        values = result[name]
        if not isinstance(values, list) or any(
            not isinstance(value, str) or not value.strip() for value in values
        ):
            raise ContractError(f"{name} must be a list of nonempty strings")
    if len(result["reasons"]) != len(result["matched_rules"]):
        raise ContractError("reasons and matched_rules must have equal lengths")
    version = result["engine_version"]
    if not isinstance(version, str) or not version.strip():
        raise ContractError("engine_version must be a nonempty string")
    return {
        "score": score,
        "risk_level": result["risk_level"],
        "reasons": list(result["reasons"]),
        "matched_rules": list(result["matched_rules"]),
        "engine_version": version,
    }
