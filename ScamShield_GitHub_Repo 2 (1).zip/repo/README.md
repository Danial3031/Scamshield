# ScamShield

ScamShield checks a pasted message and returns a risk score (0-100), a risk level (Low / Medium / High) and the reasons behind it.
The score comes from weighted rules. It is a risk indicator, not a probability, and links are never opened.

Group project, BSc Computing (Global Banking School / Bath Spa University).

## Structure
- `website/` - single-page website (`index.html`, runs entirely in the browser, 16 rules, 28 self-tests). To publish it with GitHub Pages see `website/README.md`
- `backend/` - Flask + SQLite prototype: accounts, login, CSRF protection, history, family alerts, 10 tests
- `docs/` - project explanation, short guide, and `design/` (Penpot UI design file, can be imported into Penpot)

## Status
The website and the back-end prototype are built separately. Connecting the website to the back end and database is future work.

## Run the back end
```
cd backend
pip install -r requirements.txt
python seed_demo.py
python -m flask --app app run
```
Demo login: margaret@example.com / password123

## Test the back end
```
cd backend
python -m unittest discover -s tests -v
```

## Team
Khalil (project lead, UI/UX), Ahmed (Flask back end, security, website), Lavinia (SQL database), Daneil (detection engine, testing), Adnan (family dashboard, integration, demo)
