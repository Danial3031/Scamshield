# ScamShield

A browser-based scam message checker. Paste a suspicious message (or upload a text file) and get a **risk score out of 100**, a **risk level** (Low / Medium / High) and **plain-language reasons**. Everything runs in the browser: nothing is uploaded or sent anywhere.

> The score is a sum of rule weights. It is a guide, not a probability and not a guarantee. A low score does not prove a message is safe.

## Features
- **Transparent rule engine**: 16 weighted rules kept in one data table; the score is the sum of matched weights, capped at 100 (Low below 30, Medium 30-59, High 60+).
- **Negation-aware**: "Do not share your password" is not flagged as a request.
- **Tap-to-learn**: tap a highlighted phrase to see the trick behind it.
- **Scam type and playbook**: names the likely scam type and what to do instead.
- **Link X-ray**: splits links into parts, shows the real website and flags look-alikes, shorteners, IP addresses and `@` tricks. Links are only read as text and never opened.
- **Scam or Safe? game**: 10 rounds, points, streaks and badges.
- **History**: first 90 characters of each check, stored only in the browser.
- Mobile-first, keyboard accessible, safe rendering (no `innerHTML`), strict Content-Security-Policy.

## Run it
No build step and no dependencies. Open `index.html` in a browser.

## Self-test
Open `index.html?selftest` and look at the browser console, or run `scamshieldSelfTest()` in the console. It runs 28 checks and logs pass/fail with the expected result for each.

## Publish with GitHub Pages
1. Create a repository and upload `index.html` and `README.md`.
2. Go to **Settings > Pages**, choose **Deploy from a branch**, select the `main` branch and the `/ (root)` folder, then save.
3. After a minute the site is live at `https://<your-username>.github.io/<repository-name>/`.

## Limitations
- Rules are written for English only.
- Rule weights are design choices and have not been calibrated on real data.
- The brand list used by Link X-ray is small (25 brands).
- It cannot verify who sent a message or where a link really leads.
